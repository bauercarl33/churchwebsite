// nodejs/utils/fsUtils.js
import fs from "fs/promises";

export default fs;
